% This code was written as a part of Reseacrh Methods MSc course
% Coded by: Piotr Z. Jelonek, e-mail:  p.z.jelonek@warwick.ac.uk,
% 20th February 2016
%
% Disclaimer:
% 1. This script is intended for a non-commercial use.
% 2. You can use, amend and edit it to fit to your purposes for your own use only, 
%    but not for further distribution.
% 3. This script comes with no warranty. 
% 4. Please quote the author when using the script.
%
% Copyright: The author(s) own the right to modify or amend the script and 
% claim for the authorship of it.

function dx = minsky_I_dx(tspan,x,alpha,beta,c,d,gamma,nu)
    dx=zeros(4,1);
    dx(1)=( (1/nu)*(1-x(2)/x(3))- gamma - alpha)*x(1);
    dx(2)=(d*(x(1)/x(4))-c)*x(2);
    dx(3)=alpha*x(3);
    dx(4)=beta*x(4);
end

