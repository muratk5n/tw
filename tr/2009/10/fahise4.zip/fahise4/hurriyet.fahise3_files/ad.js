var isRollOver = false;var id_counter = 0;var _TargetCampaign = "";
var blnIsNS = (navigator.appName.indexOf('Netscape') >= 0 && parseFloat(navigator.appVersion) >= 4) ? true : false;
var blnIsIE = (document.all) ? true : false;var blnIsMac= (navigator.appVersion.indexOf('Mac')!=-1) ? true : false;
function DOLAD_popup(strUrl, intWidth, intHeight, intLeft, intTop)
{DOLLcl_popWindow(strUrl, intWidth, intHeight, intLeft, intTop, true);}
function DOLAD_popunder(strUrl, intWidth, intHeight, intLeft, intTop)
{DOLLcl_popWindow(strUrl, intWidth, intHeight, intLeft, intTop, false);}
function DOLLcl_popWindow(strUrl, intWidth, intHeight, intLeft, intTop, blnFocus) {
	var lclIntLeft=(intLeft==null || intLeft==0)?(screen.width-intWidth)/2:intLeft;
	var lclIntTop=(intTop==null || intTop==0)?(screen.height-intHeight)/2:intTop;
	var lclObjWin = window.open(strUrl,'ekolay','toolbar=0,status=0,menubar=0,resizable=0,scrollbars=0,width='+intWidth+'px,height='+intHeight+'px,left=' + lclIntLeft + ',top=' +lclIntTop);
	if(!blnFocus) {
		lclObjWin.blur();
		self.focus();
	}
}
function DOLAD_flash(strUrl, intWidth, intHeight, intTop, intLeft, strMode) {
	var lclStrMode=(strMode==null)?"transparent":strMode;
	var tmp = '';
	if(intTop!=null) 
		tmp = '';
		tmp += ('<div style="position:relative;width:'+intWidth+'px;height:'+intHeight+'px;z-index:9999"><OBJECT style="position:absolute;left:0px;top:0px;z-index:9999;" border="0" height="'+intHeight+'" width="'+intWidth+'" align="top" id="Flash_'+strUrl+'"'+ 
		' codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"'+
		' height="'+intHeight+'" width="'+intWidth+'" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" >'+
		'<PARAM NAME="movie" VALUE="'+strUrl+'">'+
		'<PARAM NAME="quality" VALUE="high">'+
		'<PARAM NAME="wmode" VALUE="'+lclStrMode+'">'+
		'<embed ID="embedFlash_'+strUrl+'" '+
		' src="'+strUrl+'"'+
		' quality="high" wmode="'+lclStrMode+'"'+
		' pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"'+
		' type="application/x-shockwave-flash" width="'+intWidth+'" height="'+intHeight+'"></embed>'+
		'</OBJECT></div>');
		if(intTop!=null) {
			tmp = '';
		} 
	document.write(tmp);
}
function DOLAD_rollover(strUrl, intWidth, intHeight, clickUrl, rawClickUrl, strMode,intMinWidth,intMinHeight) {
	isRollOver = true;
	var lclStrMode=(strMode==null)?"transparent":strMode;
	var tempStrUrl=(rawClickUrl!="http://")?strUrl+clickUrl:strUrl;
	strUrl=tempStrUrl;
	var lclStrBnrId = "Bnr_"+(id_counter++)
 	document.write("<div id='"+lclStrBnrId+"'></div>");
	if (window.navigator.appName.toLowerCase().indexOf('explorer') < 0)
	{
		if(typeof intMinWidth == "undefined" || intMinWidth == null)return;
		if(typeof intMinHeight =="undefined" || intMinHeight == null)return;
		var arrHTML = [];
		arrHTML.push("<div onmouseout=this.style.width='"+String(intMinWidth)+"px';this.style.height='"+String(intMinHeight)+"px' onmouseover=this.style.width='"+String(intWidth)+"px';this.style.height='"+String(intHeight)+"px' style='width:"+String(intMinWidth)+"px;height:"+String(intMinHeight)+"px;position:relative;overflow:hidden;z-index:999999'>");
		arrHTML.push('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="'+String(intWidth)+'" height="'+String(intHeight)+'">');
		arrHTML.push('<param name="movie" value="'+strUrl+'" />');
		arrHTML.push('<param name="quality" value="high" />');
		arrHTML.push('<param name="wmode" value="'+lclStrMode+'" />');
		arrHTML.push('<embed style="position:relative;z-index:9999;" src="'+strUrl+'" width="'+String(intWidth)+'" height="'+String(intHeight)+'" allowScriptAccess="sameDomain" allowFullScreen="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent"></embed>');
		arrHTML.push("</div>");
		document.write(arrHTML.join(''));
	}
	else{
 	var lyr = document.getElementById(lclStrBnrId);
 	var position = "";//(blnIsIE) ? '' : 'left:' + lyr.PageX + ';top:' + lyr.PageY;
	var tmp;
	tmp = ''+
	'<div style="position:relative;top:0px;width:'+intWidth+'px;z-index:9999"><OBJECT onmouseover="try{DOLBNR_hide();} catch(e) {}" onmouseout="try{DOLBNR_show();} catch(e) {}"'+
	' style="position:absolute;left:0px;top:0px;z-index:9999;"' +
	' codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"'+
	' width="'+intWidth+'" height="'+intHeight+'"'+
	' classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+
	'>'+
	'<PARAM NAME="movie" VALUE="'+strUrl+'">'+
	'<PARAM NAME="quality" VALUE="high">'+
	'<PARAM NAME="wmode" VALUE="'+lclStrMode+'">'+
	'<embed'+
	' src="'+strUrl+'"'+
	' quality="high"'+
	' pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"'+
	' type="application/x-shockwave-flash"'+
	' style="position:relative; z-index:9999; '+ position + '"' + 
	' wmode="'+lclStrMode+'"'+
	' width="'+intWidth+'" height="'+intHeight+'"'+
	'></embed>'+
	'</OBJECT></div>';
	
	document.write(tmp);
	}
}
function DOLAD_img(strHTML){document.write(strHTML);}
function DOLAD_HTML(strHTML){document.write(strHTML);}
function DOLAD_floating(strURL, clickURL, intWidth, intHeight, intLeft, intTop)
{
if (window.navigator.appName.toLowerCase().indexOf('explorer') > 0)
	{
	var lclIntX=(intLeft==null)?0:intLeft;
	var lclIntY=(intTop==null)?0:intTop;
	var rnd=Math.ceil(Math.random()*99999999);
	var clientWidth=document.body.offsetWidth;
	var clientHeight=document.body.offsetHeight;
	if (clientWidth<770) clientWidth=792;
	var positionLeft=(lclIntX==0)?(clientWidth/2)-(intWidth/2):lclIntX;
	var positionTop=(lclIntY==0)?(clientHeight/2)-(intHeight/2):lclIntY;
	var tmp= ''+
	'<div id="floatingDiv'+rnd+'" '+
	' align="center" style="position: absolute; width:'+intWidth+'px; height:'+intHeight+'px; z-index:100;"> '+
	' <object id="flashobj'+rnd+'" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" '+
	' codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" '+
	' width="'+intWidth+'" height="'+intHeight+'" align="middle"> '+
	'    <param name=movie value="'+strURL+clickURL+'"> '+
	'    <param name=quality value=high> '+
	'    <param name="BGCOLOR" value=""> '+
	'    <param name=scale value=noborder> '+
	'    <param name=wmode value=transparent> '+
	'    <embed id="floatingEmbed'+rnd+'" src="'+strURL+clickURL+'" quality=high wmode=transparent  scale=noborder pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" '+
	' width="'+intWidth+'" height="'+intHeight+'" align="absmiddle"> '+
	'    </embed> </div> '+
	'  </object> '+
	'<script language="javascript"> '+
	'window.floatingDiv'+rnd+'.style.left='+positionLeft+'; '+
	'window.floatingDiv'+rnd+'.style.top='+positionTop+'; '+
	'</SCRIPT> ';
	document.write (tmp);
	}
}
function DOLAD_RePos(){}  
function getCookie(strName) {
	var arrCookie = document.cookie.split(";");
	for (var i=0; i < arrCookie.length; i++) {
		var cookie = arrCookie[i].split("=");
		while(cookie[0].indexOf(" ")==0) cookie[0]=cookie[0].substr(1);
		if (strName == cookie[0]) return unescape(cookie[1]);
	}
	return "";
}
function DOL_createcookie(name,value,days)
{
if (days)
{
var date = new Date();
date.setTime(date.getTime()+(days*24*60*60*1000));
var expires = "; expires="+date.toGMTString();
}
else var expires = "";
document.cookie = name+"="+value+expires+"; path=ad.e-kolay.net";
} 
function setCookie(strName, strValue){document.cookie = strName + "=" + escape(strValue);}

function flashCookie(cookiename)
{
	var getCookieObj = document.getElementById(cookiename)
	var cookieValue=getCookie(cookiename);
	if(getCookieObj == null)
		setTimeout("flashCookie('"+ cookiename + "');",200);
	else
		getCookieObj.SetVariable('_root.cookievalue',cookieValue);
}