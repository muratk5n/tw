if (top != self) { 
	top.location = self.location; 
}

function jumpto(x){

if (document.yazarlar.jumpmenu.value != "null") {
	document.location.href = x
	}
}

function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=350,height=350,left = 337,top = 234');");
}

function BizeYazin(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=410,height=330,left = 337,top = 200');");
}

function kapak(){
window.open('http://www.yenisafak.com.tr/kapak.html','','width=1020,height=720,status=no,toolbar=no,scrollbars=yes,resizable=no,navbar=no,left=0,top=0');
}
