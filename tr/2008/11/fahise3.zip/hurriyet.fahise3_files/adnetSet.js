ADNET_anaTablo="border:1px solid #D5DEC8;width:100%;border-collapse:collapse;padding:1px 1px 1px 1px";

ADNET_adDisTD="padding:2px 2px 2px 2px;";

ADNET_adTablo="border-collapse:collapse;";

ADNET_adTDMetin="font:11px Tahoma;color:#818181;";

ADNET_adTDBaslik="font:bold 11px Tahoma;color:#384525;";

ADNET_adBaslikLink="font:bold 12px Arial;color:#384525;text-decoration:none;padding-bottom:3px;";

ADNET_adLink="font:10px Tahoma;color:#384525;text-decoration:none;word-break: break-all;padding-top:2px;";

ADNET_adTDUrl="font:12px Tahoma;color:#384525;";

ADNET_DVMetin1="font:11px Tahoma;color:#7B8074";

ADNET_DVMetin2="font:11px Tahoma;color:#7B8074";

ADNET_fotoDiv="";

ADNET_fotoIMG="vertical-align:top;text-align:left";

var adDefaultFooterText = "<span style=\"font:11px Arial;color:aaaaaa;padding-left:2px;\">Reklam vermek i�in t�klay�n�z.</span>";

